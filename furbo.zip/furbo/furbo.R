# furbo
# ARTICULO DE PERICODICO CON 1000 PALABRAS
if (!require("pacman")) install.packages("pacman")
pacman::p_load(tidyverse,haven,readr,readxl,ggplot2,stargazer, gmodels, ggsoccer, worldfootballR,jpeg,BiocManager)
install.packages("devtools")
library(devtools)
devtools::install_github("FC.rSTATS")
#understatr

# NO CONSIGO QUE FUNCIONE ESTA LIBRERIA
"http://statsbomb.com/wp-content/uploads/2019/07/Using-StatsBomb-Data-In-R-Spanish.pptx.pdf"


# APARTIR DE AQUI CONSIGO UNA NUEVA Y YA DATOS!!!
# s epuede sacar datos de messi del partido de laa final, ns como usarlo. 
finalarg<- fb_player_match_logs(player_url = "https://fbref.com/en/players/d70ce98e/Lionel-Messi",
                                season_end_year = 2023,
                                stat_type = 'summary')

#fb_player_urls("https://fbref.com/en/squads/fd962109/Fulham-Stats")

# aqui tenemos todos los datos de messi en el mundial y mas años. 
messi_fbref <- fb_player_scouting_report(player_url = "https://fbref.com/en/players/d70ce98e/Lionel-Messi", 
                                           pos_versus = "primary")
prueba<- messi_fbref %>% select(Statistic)

#PARA_SACAR_TEMPORADAS <- fb_player_match_logs(player_url = "https://fbref.com/en/players/d70ce98e/Lionel-Messi",season_end_year = 2016,
                              #stat_type = "summary")



messi_GOAL_assist <- fb_player_goal_logs(player_url = "https://fbref.com/en/players/d70ce98e/Lionel-Messi", 
                                        goals_or_assists = "both")


# CRISTIANO
"https://fbref.com/en/players/dea698d9/Cristiano-Ronaldo" 

CR_primary <- fb_player_scouting_report(player_url = "https://fbref.com/en/players/dea698d9/Cristiano-Ronaldo", 
                                        pos_versus = "primary")

CR_GOAL_assist <- fb_player_goal_logs(player_url = "https://fbref.com/en/players/dea698d9/Cristiano-Ronaldo", 
                                         goals_or_assists = "both")
# COMPARACIONES

Data_temporadas <- fb_player_season_stats(
  player_url = c(
    "https://fbref.com/en/players/d70ce98e/Lionel-Messi",
    "https://fbref.com/en/players/dea698d9/Cristiano-Ronaldo"
  ),
  stat_type = "standard"
)

# creo q esto no nos interesa
Data_tiempo_jugado <- fb_player_season_stats(
    player_url = c(
      "https://fbref.com/en/players/d70ce98e/Lionel-Messi",
      "https://fbref.com/en/players/dea698d9/Cristiano-Ronaldo",
    stat_type = "playing_time"
  ))



# Leer los archivos de Excel
messiselecc <- read_xlsx("messi.xlsx")
cr7selecc <- read_xlsx("cr7.xlsx")

messiselecc <- messiselecc %>%
  mutate(Temporada = as.character(Temporada))

cr7selecc <- cr7selecc %>%
  mutate(Temporada = as.character(Temporada))

# Realizar la unión con full_join
Data_selecciones <- full_join(messiselecc, cr7selecc)

# NO FUNCIONA
Data_selecciones <- fb_player_season_stats(
  player_url = c(
    "https://fbref.com/es/jugadores/d70ce98e/nat_tm/Estadisticas-del-equipo-nacional-Lionel-Messi",
    "https://fbref.com/en/players/dea698d9/Cristiano-Ronaldo"
  ),
  stat_type = "gca"
)

# hay mas funciones que con links de la pagina https://fbref.com/en/ se puede conseguir mas info. Mañana a la mañana pruebo.

liga_2020 <- fb_match_results(country = "ESP", 
                              gender = "M", 
                              season_end_year = 2020, 
                              tier = "1st")

get_png <- function(filename) {
  grid::rasterGrob(png::readPNG(filename), interpolate = TRUE)
}

bar <- get_png("barca.png") 
madr <- get_png("madrid.png") 
inter <- get_png("Inter_Miami_CF_logo.svg.png") 
moro <- get_png("alnasser.png") 
arge <- get_png("argentina.png") 
portu <- get_png("portugal.png") 

# se pueden sacar datos por cada partido metiendo el link por si nos intersa algun aprtido.

# empezar a graficar y todo eso

# CAMPO DE FUTBOL

ggplot() +
  annotate_pitch(fill = "#1b893e", colour = "white") +
  theme_pitch() +
  theme(panel.background = element_rect(fill = "#186d33"))
  # sin tener que crear data set

Data_temporadas %>% group_by(player_name,Age) %>% 
    summarise(gol_asist = sum(`G+A`, na.rm = T)) %>% 
  ungroup() %>% 
  ggplot((aes(Age,gol_asist)))+
  geom_point(aes(color = player_name), size = 2)+
  geom_line(aes(color = player_name), linewidth = 1)+
  scale_color_manual(values = c(alpha("grey",0.5), "#A50044")) + 
  labs(
    title = "Messi VS CR7",
    subtitle = "Goles y assistencias por temporada en todas las competiciones",
    x = "Edad",
    y = "G+A",
    color = "Jugadores",
    caption = "FBREF.com"
  ) +
  geom_text(x = 33,
            y = 85,
            label = "El peak de ambos",
            family = "Times New Roman", 
            color = "darkgrey")+
  theme_minimal()+
  theme(panel.grid.major.x = element_blank(), 
        panel.grid.minor.y = element_blank())+
  annotation_custom(bar, xmin = 20, xmax = 25, ymin = 85, ymax = 90)+
  annotation_custom(madr, xmin = 26, xmax = 31, ymin = 82, ymax = 87)+
  annotation_custom(inter, xmin = 34, xmax = 39, ymin = 0, ymax = 5)+
  annotation_custom(moro, xmin = 35, xmax = 40, ymin = 40, ymax = 45)




# GRAPH 2

prueb <- Data_selecciones %>% filter(Comp != "Friendlies (M)") %>% 
  mutate(Ast = ifelse(is.na(Ast), 0, Ast)) %>% 
    mutate(gol_asist = Gls + Ast)
  
# todas las competiciones
Data_selecciones %>% filter(Comp != "Friendlies (M)") %>% 
  group_by(Equipo, Edad) %>% 
  mutate(Ast = ifelse(is.na(Ass), 0, Ass)) %>% 
  mutate(gol_asist = Gls + Ass) %>% 
  ungroup() %>% 
  ggplot(aes(Edad,gol_asist))+
  geom_point(aes(color = Equipo), size = 2)+
  geom_step(aes(color = Equipo), size = 1)+
  scale_color_manual(values = c("red", "lightblue")) + 
  labs(
    title = "Messi VS CR7",
    subtitle = "Goles y assistencias con SELECCIONES",
    x = "Edad",
    y = "G+A",
    color = "Jugadores",
    caption = "FBREF.com"
  ) +
  theme_minimal()+
  theme(panel.grid.major.x = element_blank(), 
        panel.grid.minor.x = element_blank(),
        panel.grid.minor.y = element_blank())

# Lo que nos pidio borja. messi hasta los 26 solo 1 gol y 0 asistencias. 
 Data_selecciones %>%
  filter(Comp != "Friendlies (M)") %>%
  mutate(Ast = ifelse(is.na(Ast), 0, Ast)) %>%
  group_by(player_name, Age) %>%
  summarise(Gls = sum(Gls), Ast = sum(Ast)) %>%
  mutate(gol_asist = cumsum(Gls + Ast)) %>% 
  ungroup() %>% 
ggplot(aes(Age,gol_asist))+
  geom_point(aes(color = player_name), size = 2)+
  geom_step(aes(color = player_name), size = 1)+
  scale_color_manual(values = c("red", "lightblue")) + 
  labs(
    title = "Messi VS CR7",
    subtitle = "Goles y assistencias con SELECCIONES",
    x = "Edad",
    y = "G+A",
    color = "Jugadores",
    caption = "FBREF.com"
  ) +
  theme_minimal()+
  theme(panel.grid.major.x = element_blank(), 
        panel.grid.minor.x = element_blank(),
        panel.grid.minor.y = element_blank())+
  annotation_custom(portu, xmin = 50, xmax = 52, ymin = 58, ymax = 68) +
  annotation_custom(arge, xmin = 49, xmax = 51, ymin = 48, ymax = 58) +
  coord_cartesian(clip = "off") +
  theme(plot.margin = unit(c(1, 1, 3, 1), "lines"))

Data_selecciones %>% filter(Comp != "Friendlies (M)",Comp != "WCQ" &Comp!= "UEFA Euro Qualifying") %>% 
  mutate(Ast = ifelse(is.na(Ast), 0, Ast)) %>%
  group_by(player_name, Age) %>%
  summarise(Gls = sum(Gls), Ast = sum(Ast)) %>%
  mutate(gol_asist = cumsum(Gls + Ast)) %>% 
  ungroup() %>% 
  ggplot(aes(Age,gol_asist))+
  geom_point(aes(color = player_name), size = 2)+
  geom_step(aes(color = player_name), size = 1)+
  scale_color_manual(values = c("red", "lightblue")) + 
  labs(
    title = "Messi VS CR7",
    subtitle = "Goles y assistencias con SELECCIONES",
    x = "Edad",
    y = "G+A",
    color = "Jugadores",
    caption = "FBREF.com"
  ) +
  theme_minimal()+
  theme(panel.grid.major.x = element_blank(), 
        panel.grid.minor.x = element_blank(),
        panel.grid.minor.y = element_blank())+
  annotation_custom(portu, xmin = 48, xmax = 50, ymin = 21, ymax = 23) +
  annotation_custom(arge, xmin = 47, xmax = 49, ymin = 17, ymax = 20) +
  coord_cartesian(clip = "off") +
  theme(plot.margin = unit(c(1, 1, 3, 1), "lines"))



# graph 3 y 4
#GOLES Y ASSISTE EN COMPETICIONES CON SELECCION
 
 Data_selecciones %>% filter(Comp != "Friendlies (M)") %>% 
   mutate(Ast = ifelse(is.na(Ast), 0, Ast)) %>% 
   mutate(gol_asist = Gls + Ast) %>% filter(player_name== "Cristiano Ronaldo") %>% group_by(Comp) %>% 
   summarise(gol_asist = sum(`G+A`, na.rm = T)) %>% 
   ggplot(aes(reorder(Comp, (gol_asist)),gol_asist))  +
     geom_bar(stat = "identity", fill = "#8B0000")+
  coord_flip()+
  labs(
    title = "CR7",
    subtitle = "Goles y assistencias en Torneos",
    x = "Edad",
    y = "G+A",
    caption = "FBREF.com"
  ) +
  theme_minimal()+
  theme(panel.grid.minor.x = element_blank(),
        panel.grid.minor.y = element_blank(),
        panel.grid.major.y = element_blank())

 Data_selecciones %>% filter(Comp != "Friendlies (M)") %>% 
   mutate(Ast = ifelse(is.na(Ast), 0, Ast)) %>% 
   mutate(gol_asist = Gls + Ast) %>% filter(player_name== "Lionel Messi") %>% group_by(Comp) %>% 
   summarise(gol_asist = sum(`G+A`, na.rm = T)) %>% 
  ggplot(aes(reorder(Comp,(gol_asist)), gol_asist))+
  geom_bar(stat = "identity", fill = "#75AADB")+
  coord_flip()+
  labs(
    title = "Messi",
    subtitle = "Goles y assistencias en Torneos",
    x = "Edad",
    y = "G+A",
    caption = "FBREF.com"
  ) +
  theme_minimal()+
  theme(panel.grid.minor.x = element_blank(),
        panel.grid.minor.y = element_blank(),
        panel.grid.major.y = element_blank())

# sin aprtidos de clasificacion. solo torneos
 Data_selecciones %>% filter(Comp != "Friendlies (M)") %>% 
   mutate(Ast = ifelse(is.na(Ast), 0, Ast)) %>% 
   mutate(gol_asist = Gls + Ast) %>% filter(player_name== "Cristiano Ronaldo" & Comp!= "WCQ" &Comp!= "UEFA Euro Qualifying") %>% 
   group_by(Comp) %>% 
   summarise(gol_asist = sum(`G+A`, na.rm = T)) %>% 
   ggplot(aes(reorder(Comp, (gol_asist)),gol_asist))  +
   geom_bar(stat = "identity", fill = "#8B0000")+
   coord_flip()+
   labs(
     title = "CR7",
     subtitle = "Goles y assistencias en Torneos Mayores",
     x = "Edad",
     y = "G+A",
     caption = "FBREF.com"
   ) +
   theme_minimal()+
   theme(panel.grid.minor.x = element_blank(),
         panel.grid.minor.y = element_blank(),
         panel.grid.major.y = element_blank())

 Data_selecciones %>% filter(Comp != "Friendlies (M)") %>% 
   mutate(Ast = ifelse(is.na(Ast), 0, Ast)) %>% 
   mutate(gol_asist = Gls + Ast) %>% filter(player_name== "Lionel Messi" & Comp!= "WCQ" & Comp!= "UEFA Euro Qualifying") %>% group_by(Comp) %>% 
  summarise(gol_asist = sum(`G+A`, na.rm = T)) %>%
  ggplot(aes(reorder(Comp,(gol_asist)), gol_asist))+
  geom_bar(stat = "identity", fill = "#75AADB")+
  coord_flip()+
  labs(
    title = "Messi",
    subtitle = "Goles y assistencias en Torneos Mayores",
    x = "Edad",
    y = "G+A",
    caption = "FBREF.com"
  ) +
  theme_minimal()+
  theme(panel.grid.minor.x = element_blank(),
        panel.grid.minor.y = element_blank(),
        panel.grid.major.y = element_blank())





# graficos de mayores achievments ns como se dice en español ni como se escribe en ingles
# ideas para seguir.

# con messi_fbfref se pyeden sacar datos del mundial(o otra competiciomn) y comparar con cristiano. 
#Se puede ahcer mundial VS eurocopa de cristiano. o copa america vs eurocopa.

# con messi_GOAL_ igyual s epuede hacer un cuerpo humano y poner messi cuantos 
#goles a metido con cada aprte y lo mismo conc ristiano.

# con data seleccione sigual quien ha ayudado mas a su seleccion en mundiales comaparando datos. 


# prueba in fo extra

 
messi_disparos<- understat_player_shots("https://understat.com/player/2097")
cr7_disparos<- understat_player_shots("https://understat.com/player/2371")

#prueba1 
a<- messi_disparos %>% filter(result== "Goal", minute>=70) %>% 
  mutate(x1= 100* X ) %>% 
  mutate(y1 = 100-(100* Y)) 

  ggplot(a,(aes(x1,y1)))+
  annotate_pitch(fill = "#1b893e", colour = "white") +
  geom_point()+
  theme(panel.background = element_rect(fill = "#186d33"))+
  theme_pitch()


  ggplot() +
  annotate_pitch(fill = "#1b893e", colour = "white") +
  theme_pitch() +
  theme(panel.background = element_rect(fill = "#186d33"))

  # def bueno

  messi.tiros.prep <- messi_disparos %>% filter(season== 2020) %>% 
    mutate(is.goal = ifelse(result == "Goal", result, "No Goal"))

  
  #IDEAS BORJA
  
  # mejora de campo
  # si no es goal que no tenga fill. Xg sea gradient. 
  # X = XG, Y= GOAL. METER MUCHOS JUGADORES POR TEMPORADAS.
  ggplot(messi.tiros.prep)+
    annotate_pitch(fill = "white", colour = "black") +
    geom_point(data = messi.tiros.prep,
               aes(x = X * 100,
                   y = 100-(Y * 100),
                   size = xG,
               color = is.goal),
               fill = "#0233a0",
               shape = 21) +
    scale_color_manual(values = c("Goal" = "#0233a0", "No Goal" = "red")) +
    scale_alpha_discrete(range = c(1, 0.4)) +
    coord_flip(xlim = c(49, 101),
               ylim = c(-12, 112)) +
    ggtitle("Messi - Mapa de tiros ")+
    theme(panel.background = element_rect(fill = "#white"))+
    theme_pitch()
  

  
  # Crear el gráfico
  
  
  # Crear el gráfico
  library(ggplot2)
  library(ggsoccer)
  
  # EL BUENO
  messi.tiros.prep <- messi_disparos %>% filter(season== 2020) %>% 
    mutate(is.goal = ifelse(result == "Goal", result, "No Goal"))

  ggplot(messi.tiros.prep) +
    annotate_pitch(fill = "white", colour = "black") +
    geom_point(data = subset(messi.tiros.prep, is.goal == "Goal"),
               aes(x = X * 100,
                   y = 100 - (Y * 100),
                   size = xG,
                   fill = xG),
               color = "black",
               shape = 21) +
    geom_point(data = subset(messi.tiros.prep, is.goal == "No Goal"),
               aes(x = X * 100,
                   y = 100 - (Y * 100),
                   size = xG),
               color = "red",
               shape = 21) +
    scale_fill_gradient(low = "lightgreen", high = "darkgreen") +
    coord_flip(xlim = c(49, 101),
               ylim = c(-12, 112)) +
    ggtitle("Messi - Mapa de tiros") +
    theme(panel.background = element_rect(fill = "white")) +
    theme_pitch()
  
  cr7.tiros.prep <- cr7_disparos %>% filter(season== 2020) %>% 
    mutate(is.goal = ifelse(result == "Goal", result, "No Goal"))
  
    ggplot(cr7.tiros.prep) +
    annotate_pitch(fill = "white", colour = "black") +
    geom_point(data = subset(cr7.tiros.prep, is.goal == "Goal"),
               aes(x = X * 100,
                   y = 100 - (Y * 100),
                   size = xG,
                   fill = xG),
               color = "black",
               shape = 21) +
    geom_point(data = subset(cr7.tiros.prep, is.goal == "No Goal"),
               aes(x = X * 100,
                   y = 100 - (Y * 100),
                   size = xG),
               color = "black",
               shape = 21) +
    scale_fill_gradient(low = "lightgreen", high = "darkgreen") +
    coord_flip(xlim = c(49, 101),
               ylim = c(-12, 112)) +
    ggtitle("CR7 - Mapa de tiros") +
    theme(panel.background = element_rect(fill = "white")) +
    theme_pitch()
  
